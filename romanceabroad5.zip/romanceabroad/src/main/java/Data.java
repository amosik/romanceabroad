public class Data {
    //Registration page
    public static final String email = "test@gmail.com";
    public static final String password = "1234test";
    public static final String user_name = "Alexa";
    public static final String phone_number = "14156576565";


    //Search page
    public static final String expectedUrlSearch = "https://romanceabroad.com/users/search";

    //View page
    public static final String expectedUrlView = "https://romanceabroad.com/content/view/how-it-works";

    //Gifts page
    public static final String expectedUrGift = "https://romanceabroad.com/store/category-sweets";

}
